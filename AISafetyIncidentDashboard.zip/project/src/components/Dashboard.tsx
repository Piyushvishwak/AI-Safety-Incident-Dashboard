import React, { useState, useEffect } from 'react';
import { Incident, Severity } from '../types/incident';
import { mockIncidents } from '../data/mockIncidents';
import IncidentList from './IncidentList';
import IncidentFilters from './IncidentFilters';
import IncidentForm from './IncidentForm';
import { Shield, AlertTriangle, TrendingUp } from 'lucide-react';

const Dashboard: React.FC = () => {
  const [incidents, setIncidents] = useState<Incident[]>(mockIncidents);
  const [filteredIncidents, setFilteredIncidents] = useState<Incident[]>(mockIncidents);
  const [selectedSeverity, setSelectedSeverity] = useState<string>('All');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');
  const [totalIncidents, setTotalIncidents] = useState<number>(0);

  const handleAddIncident = (newIncident: Omit<Incident, 'id'>) => {
    const id = Math.max(0, ...incidents.map((inc) => inc.id)) + 1;
    const incidentWithId: Incident = { ...newIncident, id };
    setIncidents((prevIncidents) => [incidentWithId, ...prevIncidents]);
  };

  const handleSeverityChange = (severity: string) => {
    setSelectedSeverity(severity);
  };

  const handleSortOrderChange = (order: 'newest' | 'oldest') => {
    setSortOrder(order);
  };

  useEffect(() => {
    let filtered = [...incidents];
    if (selectedSeverity !== 'All') {
      filtered = filtered.filter((incident) => incident.severity === selectedSeverity);
    }

    filtered.sort((a, b) => {
      const dateA = new Date(a.reported_at).getTime();
      const dateB = new Date(b.reported_at).getTime();
      return sortOrder === 'newest' ? dateB - dateA : dateA - dateB;
    });

    setFilteredIncidents(filtered);
    setTotalIncidents(incidents.length);
  }, [incidents, selectedSeverity, sortOrder]);

  const getIncidentCountBySeverity = (severity: Severity): number => {
    return incidents.filter(incident => incident.severity === severity).length;
  };

  return (
    <div className="max-w-6xl mx-auto px-3 sm:px-4 py-4 sm:py-8 space-y-4 sm:space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4 pb-4 sm:pb-6 border-b border-gray-200">
        <div className="flex items-center gap-3">
          <Shield className="w-8 sm:w-10 h-8 sm:h-10 text-blue-600" />
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-gray-900">AI Safety Incident Dashboard</h1>
            <p className="text-sm sm:text-base text-gray-600">Monitoring and reporting AI safety concerns</p>
          </div>
        </div>
        <div className="flex items-center gap-2 bg-blue-50 px-3 sm:px-4 py-2 rounded-lg self-start sm:self-auto">
          <TrendingUp className="w-4 sm:w-5 h-4 sm:h-5 text-blue-600" />
          <span className="text-sm sm:text-base text-blue-700 font-medium">{totalIncidents} Total Incidents</span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-6">
        <div className="bg-white rounded-xl shadow-sm p-4 sm:p-6 border border-l-4 border-emerald-500 hover:shadow-md transition-shadow duration-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm font-medium text-gray-500">Low Severity</p>
              <p className="text-2xl sm:text-3xl font-bold text-gray-900 mt-1">{getIncidentCountBySeverity('Low')}</p>
              <p className="text-xs sm:text-sm text-emerald-600 mt-1">Monitoring Required</p>
            </div>
            <div className="w-10 sm:w-12 h-10 sm:h-12 rounded-full bg-emerald-100 flex items-center justify-center">
              <AlertTriangle className="w-5 sm:w-6 h-5 sm:h-6 text-emerald-600" />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-4 sm:p-6 border border-l-4 border-amber-500 hover:shadow-md transition-shadow duration-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm font-medium text-gray-500">Medium Severity</p>
              <p className="text-2xl sm:text-3xl font-bold text-gray-900 mt-1">{getIncidentCountBySeverity('Medium')}</p>
              <p className="text-xs sm:text-sm text-amber-600 mt-1">Immediate Attention</p>
            </div>
            <div className="w-10 sm:w-12 h-10 sm:h-12 rounded-full bg-amber-100 flex items-center justify-center">
              <AlertTriangle className="w-5 sm:w-6 h-5 sm:h-6 text-amber-600" />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-4 sm:p-6 border border-l-4 border-red-500 hover:shadow-md transition-shadow duration-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm font-medium text-gray-500">High Severity</p>
              <p className="text-2xl sm:text-3xl font-bold text-gray-900 mt-1">{getIncidentCountBySeverity('High')}</p>
              <p className="text-xs sm:text-sm text-red-600 mt-1">Critical Response</p>
            </div>
            <div className="w-10 sm:w-12 h-10 sm:h-12 rounded-full bg-red-100 flex items-center justify-center">
              <AlertTriangle className="w-5 sm:w-6 h-5 sm:h-6 text-red-600" />
            </div>
          </div>
        </div>
      </div>
      
      <IncidentForm onAddIncident={handleAddIncident} />
      
      <IncidentFilters
        selectedSeverity={selectedSeverity}
        sortOrder={sortOrder}
        onSeverityChange={handleSeverityChange}
        onSortOrderChange={handleSortOrderChange}
      />
      
      <IncidentList incidents={filteredIncidents} />
    </div>
  );
};

export default Dashboard;