import React, { useState } from 'react';
import { Incident } from '../types/incident';
import SeverityBadge from './SeverityBadge';
import { ChevronDown, ChevronUp, Clock, AlertCircle } from 'lucide-react';

interface IncidentItemProps {
  incident: Incident;
}

const IncidentItem: React.FC<IncidentItemProps> = ({ incident }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const toggleExpanded = () => {
    setIsExpanded(!isExpanded);
  };

  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(date);
  };

  return (
    <div 
      className={`
        bg-white rounded-lg border border-gray-100 overflow-hidden transition-all duration-300
        hover:shadow-lg hover:border-blue-100 hover:transform hover:-translate-y-1
        ${isExpanded ? 'shadow-md' : 'shadow-sm'}
      `}
    >
      <div className="p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex-grow">
          <div className="flex items-start gap-3">
            <div className="mt-1">
              <AlertCircle 
                className={`
                  w-5 h-5
                  ${incident.severity === 'High' ? 'text-red-500' : 
                    incident.severity === 'Medium' ? 'text-amber-500' : 
                    'text-emerald-500'}
                `}
              />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 leading-tight">{incident.title}</h3>
              <div className="flex flex-wrap items-center mt-2 gap-3 text-sm text-gray-600">
                <SeverityBadge severity={incident.severity} />
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  <span>{formatDate(incident.reported_at)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <button
          onClick={toggleExpanded}
          className={`
            flex items-center justify-center px-4 py-2 text-sm font-medium rounded-md
            transition-all duration-200 min-w-[120px]
            ${isExpanded 
              ? 'bg-blue-100 text-blue-700 hover:bg-blue-200' 
              : 'bg-gray-50 text-gray-700 hover:bg-gray-100'}
            focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50
          `}
        >
          {isExpanded ? (
            <>
              <span>Hide Details</span>
              <ChevronUp size={16} className="ml-1" />
            </>
          ) : (
            <>
              <span>View Details</span>
              <ChevronDown size={16} className="ml-1" />
            </>
          )}
        </button>
      </div>
      {isExpanded && (
        <div className="px-6 pb-6 pt-2 border-t border-gray-100 bg-gray-50">
          <p className="text-gray-700 leading-relaxed">{incident.description}</p>
        </div>
      )}
    </div>
  );
};

export default IncidentItem