import React from 'react';
import { Severity } from '../types/incident';
import { Filter, SortAsc, SortDesc } from 'lucide-react';

interface IncidentFiltersProps {
  selectedSeverity: string;
  sortOrder: 'newest' | 'oldest';
  onSeverityChange: (severity: string) => void;
  onSortOrderChange: (order: 'newest' | 'oldest') => void;
}

const IncidentFilters: React.FC<IncidentFiltersProps> = ({
  selectedSeverity,
  sortOrder,
  onSeverityChange,
  onSortOrderChange,
}) => {
  const severityOptions: (Severity | 'All')[] = ['All', 'Low', 'Medium', 'High'];

  return (
    <div className="flex flex-col sm:flex-row sm:items-center gap-4 mb-6 bg-white p-4 rounded-lg shadow-sm border border-gray-100">
      <div className="flex items-center">
        <Filter size={16} className="text-gray-500 mr-2" />
        <span className="text-sm font-medium text-gray-700 mr-2">Severity:</span>
        <div className="flex space-x-2">
          {severityOptions.map((severity) => (
            <button
              key={severity}
              onClick={() => onSeverityChange(severity)}
              className={`px-3 py-1 rounded-md text-sm transition-colors duration-150 ${
                selectedSeverity === severity
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {severity}
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center sm:ml-auto">
        <span className="text-sm font-medium text-gray-700 mr-2">Sort by Date:</span>
        <div className="flex space-x-2">
          <button
            onClick={() => onSortOrderChange('newest')}
            className={`flex items-center px-3 py-1 rounded-md text-sm transition-colors duration-150 ${
              sortOrder === 'newest'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <SortDesc size={16} className="mr-1" />
            Newest
          </button>
          <button
            onClick={() => onSortOrderChange('oldest')}
            className={`flex items-center px-3 py-1 rounded-md text-sm transition-colors duration-150 ${
              sortOrder === 'oldest'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <SortAsc size={16} className="mr-1" />
            Oldest
          </button>
        </div>
      </div>
    </div>
  );
};

export default IncidentFilters;