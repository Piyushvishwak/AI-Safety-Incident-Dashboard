import { Incident } from '../types/incident';

export const mockIncidents: Incident[] = [
  { 
    id: 1, 
    title: "Biased Recommendation Algorithm Raises Ethical Concerns", 
    description: "Our team discovered that our hiring recommendation algorithm was exhibiting concerning bias patterns. During a routine audit, we found the system consistently favoring candidates from specific educational backgrounds, creating an unintended barrier for talented individuals from non-traditional paths. This bias wasn't immediately apparent but emerged through pattern analysis, showing how subtle AI biases can perpetuate systemic inequalities. We've temporarily suspended the system and are working with our ethics board to implement more robust fairness metrics.", 
    severity: "Medium", 
    reported_at: "2025-03-15T10:00:00Z" 
  },
  { 
    id: 2, 
    title: "Critical Healthcare LLM Hallucination Incident", 
    description: "In what could have been a severe patient safety incident, our healthcare-focused LLM confidently generated completely fabricated emergency protocols. A nurse practitioner caught this before implementation, but it highlighted a critical vulnerability in our system. The model had combined fragments of correct medical procedures with hallucinated steps, creating convincing but potentially dangerous instructions. This incident has sparked an urgent review of all AI-generated medical content and led to the implementation of mandatory human verification protocols.", 
    severity: "High", 
    reported_at: "2025-04-01T14:30:00Z" 
  },
  { 
    id: 3, 
    title: "Customer Service Chatbot Privacy Concern", 
    description: "During a routine security scan, we identified that our customer service chatbot was occasionally revealing non-sensitive metadata in its responses. While no personal information was compromised, the bot sometimes referenced internal user categories and engagement metrics in its replies. This behavior wasn't causing immediate harm but raised concerns about how our AI systems handle and interpret data privacy boundaries. We've since updated our data handling protocols and implemented stricter information filtering.", 
    severity: "Low", 
    reported_at: "2025-03-20T09:15:00Z" 
  },
  {
    id: 4,
    title: "AI Model Security Breach Investigation",
    description: "Our security team detected unusual access patterns to our model weight servers during a scheduled audit. While initial investigation confirmed unauthorized access attempts, our rapid response team verified that no model weights were successfully extracted. This incident has led to a complete overhaul of our security infrastructure, including the implementation of advanced behavioral analytics and real-time monitoring systems. We're sharing our learnings with the broader AI community to prevent similar vulnerabilities.",
    severity: "Medium",
    reported_at: "2025-03-25T16:45:00Z"
  },
  {
    id: 5,
    title: "Training Data Memorization Discovery",
    description: "During a comprehensive model evaluation, we discovered our latest LLM was occasionally reproducing verbatim content from its training data. This included several instances of copyrighted material and, more concerningly, what appeared to be snippets of private conversations. This discovery has profound implications for both intellectual property rights and user privacy. We're now developing more sophisticated data filtering techniques and considering the ethical implications of large-scale text model training.",
    severity: "High",
    reported_at: "2025-03-10T11:20:00Z"
  }
];